from pydantic import BaseModel
from typing import List, Optional

class Student(BaseModel):
    id: Optional[int] = None
    name: str
    roll_no: int
    marks: float

class SortRequest(BaseModel):
    students: List[Student]
    sort_by: str  
    algorithm: str  
    order: str = "asc"  

class SortResponse(BaseModel):
    sorted_students: List[Student]
    execution_time: float
    algorithm_used: str

class SearchRequest(BaseModel):
    students: List[Student]
    search_by: str  
    value: float