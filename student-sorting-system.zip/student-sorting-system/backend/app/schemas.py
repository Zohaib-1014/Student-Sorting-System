from typing import List
from app.models import Student

def students_to_dict(students: List[Student]) -> List[dict]:
    return [student.dict() for student in students]

def dict_to_students(data: List[dict]) -> List[Student]:
    return [Student(**item) for item in data]