import time

# Simple timer function
def measure_time(func):
    """Measures execution time of a function"""
    start_time = time.time()
    result = func()
    end_time = time.time()
    execution_time = (end_time - start_time) * 1000  # Convert to milliseconds
    return result, execution_time