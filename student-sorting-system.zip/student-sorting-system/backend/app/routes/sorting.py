from fastapi import APIRouter, HTTPException
from app.models import SortRequest, SortResponse, SearchRequest, Student
from app.services.sorting_algorithms import SortingAlgorithms
from app.services.search import SearchService
from app.services.file_handler import FileHandler
from app.utils.timer import measure_time
from typing import List

router = APIRouter()

@router.post("/sort", response_model=SortResponse)
def sort_students(request: SortRequest):
    reverse = request.order == "desc"
    
    # Select algorithm
    algorithms = {
        "bubble": SortingAlgorithms.bubble_sort,
        "insertion": SortingAlgorithms.insertion_sort,
        "merge": SortingAlgorithms.merge_sort,
        "quick": SortingAlgorithms.quick_sort
    }
    
    if request.algorithm not in algorithms:
        raise HTTPException(status_code=400, detail="Invalid algorithm")
    
    # Sort and measure time
    sort_func = lambda: algorithms[request.algorithm](
        request.students, 
        request.sort_by, 
        reverse
    )
    
    sorted_students, execution_time = measure_time(sort_func)
    
    return SortResponse(
        sorted_students=sorted_students,
        execution_time=round(execution_time, 4),
        algorithm_used=request.algorithm
    )

@router.post("/search")
def search_student(request: SearchRequest):
    """Binary search for a student"""
    
    result = SearchService.binary_search(
        request.students,
        request.search_by,
        request.value
    )
    
    if result:
        return {"found": True, "student": result}
    else:
        return {"found": False, "message": "Student not found"}

@router.post("/file/save")
def save_to_file(students: List[Student]):
    """Save students to file"""
    success = FileHandler.save_to_file(students)
    
    if success:
        return {"message": "Students saved successfully"}
    else:
        raise HTTPException(status_code=500, detail="Failed to save file")

@router.get("/file/load")
def load_from_file():
    """Load students from file"""
    students = FileHandler.load_from_file()
    return {"students": students}