from fastapi import APIRouter, HTTPException
from typing import List
from app.models import Student

router = APIRouter()

# In-memory storage (simple approach)
students_db: List[Student] = []
student_id_counter = 1

@router.post("/students", response_model=Student)
def add_student(student: Student):
    """Add a new student"""
    global student_id_counter
    
    student.id = student_id_counter
    student_id_counter += 1
    students_db.append(student)
    
    return student

@router.get("/students", response_model=List[Student])
def get_all_students():
    """Get all students"""
    return students_db

@router.delete("/students/{student_id}")
def delete_student(student_id: int):
    """Delete a student by ID"""
    global students_db
    
    students_db = [s for s in students_db if s.id != student_id]
    return {"message": "Student deleted successfully"}

@router.delete("/students")
def delete_all_students():
    """Delete all students"""
    global students_db
    students_db = []
    return {"message": "All students deleted successfully"}