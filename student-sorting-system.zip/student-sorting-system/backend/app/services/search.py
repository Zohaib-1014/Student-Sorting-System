from typing import List, Optional
from app.models import Student

class SearchService:
    
    @staticmethod
    def binary_search(students: List[Student], search_by: str, value: float) -> Optional[Student]:
        left = 0
        right = len(students) - 1
        
        while left <= right:
            mid = (left + right) // 2
            mid_value = getattr(students[mid], search_by)
            
            if mid_value == value:
                return students[mid]
            elif mid_value < value:
                left = mid + 1
            else:
                right = mid - 1
        
        return None