import json
from typing import List
from app.models import Student

class FileHandler:
    
    @staticmethod
    def save_to_file(students: List[Student], filename: str = "data/students.json"):
        """Save students to JSON file"""
        try:
            data = [student.dict() for student in students]
            
            with open(filename, 'w') as f:
                json.dump(data, f, indent=2)
            
            return True
        except Exception as e:
            print(f"Error saving file: {e}")
            return False
    
    @staticmethod
    def load_from_file(filename: str = "data/students.json") -> List[Student]:
        try:
            with open(filename, 'r') as f:
                data = json.load(f)
            
            students = [Student(**item) for item in data]
            return students
        except Exception as e:
            print(f"Error loading file: {e}")
            return []