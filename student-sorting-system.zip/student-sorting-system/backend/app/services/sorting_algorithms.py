from typing import List
from app.models import Student

class SortingAlgorithms:
    
    # Bubble Sort
    @staticmethod
    def bubble_sort(students: List[Student], key: str, reverse: bool = False) -> List[Student]:
        arr = students.copy()
        n = len(arr)
        
        for i in range(n):
            for j in range(0, n - i - 1):
                val1 = getattr(arr[j], key)
                val2 = getattr(arr[j + 1], key)
                
                if isinstance(val1, str):
                    val1 = val1.lower()
                    val2 = val2.lower()
                
                if reverse:
                    if val1 < val2:
                        arr[j], arr[j + 1] = arr[j + 1], arr[j]
                else:
                    if val1 > val2:
                        arr[j], arr[j + 1] = arr[j + 1], arr[j]
        
        return arr
    
    # Insertion Sort
    @staticmethod
    def insertion_sort(students: List[Student], key: str, reverse: bool = False) -> List[Student]:
        arr = students.copy()
        
        for i in range(1, len(arr)):
            current = arr[i]
            current_val = getattr(current, key)
            if isinstance(current_val, str):
                current_val = current_val.lower()
            
            j = i - 1
            
            while j >= 0:
                compare_val = getattr(arr[j], key)
                if isinstance(compare_val, str):
                    compare_val = compare_val.lower()
                if reverse:
                    if compare_val < current_val:
                        break
                else:
                    if compare_val <= current_val:
                        break
                
                arr[j + 1] = arr[j]
                j -= 1
            
            arr[j + 1] = current
        
        return arr
    
    # Merge Sort
    @staticmethod
    def merge_sort(students: List[Student], key: str, reverse: bool = False) -> List[Student]:
        
        def merge(left, right):
            result = []
            i = j = 0
            
            while i < len(left) and j < len(right):
                left_val = getattr(left[i], key)
                right_val = getattr(right[j], key)
                
                if isinstance(left_val, str):
                    left_val = left_val.lower()
                    right_val = right_val.lower()
                
                if reverse:
                    if left_val > right_val:
                        result.append(left[i])
                        i += 1
                    else:
                        result.append(right[j])
                        j += 1
                else:
                    if left_val <= right_val:
                        result.append(left[i])
                        i += 1
                    else:
                        result.append(right[j])
                        j += 1
            
            result.extend(left[i:])
            result.extend(right[j:])
            return result
        
        def sort(arr):
            if len(arr) <= 1:
                return arr
            
            mid = len(arr) // 2
            left = sort(arr[:mid])
            right = sort(arr[mid:])
            return merge(left, right)
        
        return sort(students.copy())
    
    # Quick Sort
    @staticmethod
    def quick_sort(students: List[Student], key: str, reverse: bool = False) -> List[Student]:
        
        def sort(arr):
            if len(arr) <= 1:
                return arr
            
            pivot = arr[len(arr) // 2]
            pivot_val = getattr(pivot, key)
            
            if isinstance(pivot_val, str):
                pivot_val = pivot_val.lower()
            
            left = []
            middle = []
            right = []
            
            for student in arr:
                student_val = getattr(student, key)
                if isinstance(student_val, str):
                    student_val = student_val.lower()
                
                if reverse:
                    if student_val > pivot_val:
                        left.append(student)
                    elif student_val == pivot_val:
                        middle.append(student)
                    else:
                        right.append(student)
                else:
                    if student_val < pivot_val:
                        left.append(student)
                    elif student_val == pivot_val:
                        middle.append(student)
                    else:
                        right.append(student)
            
            return sort(left) + middle + sort(right)
        
        return sort(students.copy())