from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routes import students, sorting

app = FastAPI(title="Student Sorting System")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(students.router, prefix="/api", tags=["Students"])
app.include_router(sorting.router, prefix="/api", tags=["Sorting"])

@app.get("/")
def read_root():
    return {"message": "Student Sorting System API"}

