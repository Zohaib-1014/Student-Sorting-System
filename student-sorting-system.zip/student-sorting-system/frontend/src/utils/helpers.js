// Format execution time
export const formatTime = (time) => {
  if (time < 1) {
    return `${(time * 1000).toFixed(2)} μs`;
  }
  return `${time.toFixed(4)} ms`;
};

// Validate student data
export const validateStudent = (student) => {
  if (!student.name || student.name.trim() === '') {
    return 'Name is required';
  }
  if (!student.roll_no || student.roll_no <= 0) {
    return 'Valid roll number is required';
  }
  if (student.marks === '' || student.marks < 0 || student.marks > 100) {
    return 'Marks must be between 0 and 100';
  }
  return null;
};

// Format marks with color
export const getMarksColor = (marks) => {
  if (marks >= 90) return '#28a745';
  if (marks >= 75) return '#17a2b8';
  if (marks >= 60) return '#ffc107';
  if (marks >= 40) return '#fd7e14';
  return '#dc3545';
};