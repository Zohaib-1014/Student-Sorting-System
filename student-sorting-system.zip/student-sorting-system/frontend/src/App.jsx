import React, { useState, useEffect } from 'react';
import './App.css';
import StudentForm from './components/StudentForm';
import StudentList from './components/StudentList';
import SortingControls from './components/SortingControls';
import ExecutionTime from './components/ExecutionTime';
import SearchBar from './components/SearchBar';
import FileOperations from './components/FileOperations';
import { studentAPI, sortingAPI, fileAPI } from './services/api';

function App() {
  const [students, setStudents] = useState([]);
  const [executionTime, setExecutionTime] = useState(null);
  const [algorithmUsed, setAlgorithmUsed] = useState('');
  const [message, setMessage] = useState({ type: '', text: '' });
  const [loading, setLoading] = useState(false);

  // Load students on component mount
  useEffect(() => {
    loadStudents();
  }, []);

  // Load all students from backend
  const loadStudents = async () => {
    try {
      const data = await studentAPI.getAllStudents();
      setStudents(data);
    } catch (error) {
      console.error('Error loading students:', error);
    }
  };

  // Add a new student
  const handleAddStudent = async (student) => {
    try {
      setLoading(true);
      const newStudent = await studentAPI.addStudent(student);
      setStudents([...students, newStudent]);
      showMessage('success', 'Student added successfully!');
    } catch (error) {
      showMessage('error', 'Failed to add student. Please try again.');
      console.error('Error adding student:', error);
    } finally {
      setLoading(false);
    }
  };

  // Delete a student
  const handleDeleteStudent = async (id) => {
    try {
      setLoading(true);
      await studentAPI.deleteStudent(id);
      setStudents(students.filter((s) => s.id !== id));
      showMessage('success', 'Student deleted successfully!');
    } catch (error) {
      showMessage('error', 'Failed to delete student. Please try again.');
      console.error('Error deleting student:', error);
    } finally {
      setLoading(false);
    }
  };

  // Clear all students
  const handleClearAll = async () => {
    if (window.confirm('Are you sure you want to delete all students?')) {
      try {
        setLoading(true);
        await studentAPI.deleteAllStudents();
        setStudents([]);
        setExecutionTime(null);
        setAlgorithmUsed('');
        showMessage('success', 'All students deleted successfully!');
      } catch (error) {
        showMessage('error', 'Failed to clear students. Please try again.');
        console.error('Error clearing students:', error);
      } finally {
        setLoading(false);
      }
    }
  };

  // Sort students
  const handleSort = async (sortRequest) => {
    try {
      setLoading(true);
      const response = await sortingAPI.sortStudents(sortRequest);
      setStudents(response.sorted_students);
      setExecutionTime(response.execution_time);
      setAlgorithmUsed(response.algorithm_used);
      showMessage('success', `Students sorted using ${response.algorithm_used} sort!`);
    } catch (error) {
      showMessage('error', 'Failed to sort students. Please try again.');
      console.error('Error sorting students:', error);
    } finally {
      setLoading(false);
    }
  };

  // Search student
  const handleSearch = async (searchRequest, setSearchResult) => {
    try {
      setLoading(true);
      const response = await sortingAPI.searchStudent(searchRequest);
      setSearchResult(response);
      if (response.found) {
        showMessage('success', 'Student found!');
      } else {
        showMessage('error', 'Student not found!');
      }
    } catch (error) {
      showMessage('error', 'Failed to search. Please try again.');
      console.error('Error searching student:', error);
    } finally {
      setLoading(false);
    }
  };

  // Save to file
  const handleSaveToFile = async () => {
    try {
      setLoading(true);
      await fileAPI.saveToFile(students);
      showMessage('success', 'Students saved to file successfully!');
    } catch (error) {
      showMessage('error', 'Failed to save to file. Please try again.');
      console.error('Error saving to file:', error);
    } finally {
      setLoading(false);
    }
  };

  // Load from file
  const handleLoadFromFile = async () => {
    try {
      setLoading(true);
      const response = await fileAPI.loadFromFile();
      
      if (response.students && response.students.length > 0) {
        // Clear current students
        await studentAPI.deleteAllStudents();
        
        // Add loaded students
        for (const student of response.students) {
          await studentAPI.addStudent(student);
        }
        
        // Reload students
        await loadStudents();
        showMessage('success', `Loaded ${response.students.length} students from file!`);
      } else {
        showMessage('error', 'No students found in file!');
      }
    } catch (error) {
      showMessage('error', 'Failed to load from file. Please try again.');
      console.error('Error loading from file:', error);
    } finally {
      setLoading(false);
    }
  };

  // Show message
  const showMessage = (type, text) => {
    setMessage({ type, text });
    setTimeout(() => {
      setMessage({ type: '', text: '' });
    }, 3000);
  };

  return (
    <div className="app">
      <header className="app-header">
        <h1>🎓 Student Record Sorting System</h1>
        <p>Manage and sort student records with different algorithms</p>
      </header>

      {message.text && (
        <div className={message.type === 'success' ? 'success-message' : 'error-message'}>
          {message.text}
        </div>
      )}

      {loading && <div className="loading">Loading...</div>}

      <div className="section">
        <div className="section-title">Add Student Records</div>
        <StudentForm onAddStudent={handleAddStudent} />
      </div>

      <div className="section">
        <div className="section-title">Student List</div>
        <StudentList
          students={students}
          onDeleteStudent={handleDeleteStudent}
          onClearAll={handleClearAll}
        />
      </div>

      {students.length > 0 && (
        <>
          <div className="section">
            <div className="section-title">Sort Students</div>
            <SortingControls students={students} onSort={handleSort} />
          </div>

          {executionTime && (
            <div className="section">
              <ExecutionTime
                executionTime={executionTime}
                algorithm={algorithmUsed}
              />
            </div>
          )}

          <div className="section">
            <div className="section-title">Search Student</div>
            <SearchBar students={students} onSearch={handleSearch} />
          </div>

          <div className="section">
            <div className="section-title">File Management</div>
            <FileOperations
              students={students}
              onSave={handleSaveToFile}
              onLoad={handleLoadFromFile}
            />
          </div>
        </>
      )}

      
    </div>
  );
}

export default App;