import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000/api';

// Create axios instance
const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Student API calls
export const studentAPI = {
  // Add a new student
  addStudent: async (student) => {
    const response = await api.post('/students', student);
    return response.data;
  },

  // Get all students
  getAllStudents: async () => {
    const response = await api.get('/students');
    return response.data;
  },

  // Delete a student
  deleteStudent: async (id) => {
    const response = await api.delete(`/students/${id}`);
    return response.data;
  },

  // Delete all students
  deleteAllStudents: async () => {
    const response = await api.delete('/students');
    return response.data;
  },
};

// Sorting API calls
export const sortingAPI = {
  // Sort students
  sortStudents: async (sortRequest) => {
    const response = await api.post('/sort', sortRequest);
    return response.data;
  },

  // Search student
  searchStudent: async (searchRequest) => {
    const response = await api.post('/search', searchRequest);
    return response.data;
  },
};

// File API calls
export const fileAPI = {
  // Save to file
  saveToFile: async (students) => {
    const response = await api.post('/file/save', students);
    return response.data;
  },

  // Load from file
  loadFromFile: async () => {
    const response = await api.get('/file/load');
    return response.data;
  },
};

export default api;