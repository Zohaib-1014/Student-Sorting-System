import React, { useState } from 'react';
import './SearchBar.css';

function SearchBar({ students, onSearch }) {
  const [searchBy, setSearchBy] = useState('roll_no');
  const [searchValue, setSearchValue] = useState('');
  const [searchResult, setSearchResult] = useState(null);

  const handleSearch = () => {
    if (!searchValue) {
      alert('Please enter a value to search');
      return;
    }

    if (students.length === 0) {
      alert('Please add students first!');
      return;
    }

    // Sort students first (required for binary search)
    const sortedStudents = [...students].sort((a, b) => {
      if (searchBy === 'roll_no') {
        return a.roll_no - b.roll_no;
      } else {
        return a.marks - b.marks;
      }
    });

    onSearch(
      {
        students: sortedStudents,
        search_by: searchBy,
        value: parseFloat(searchValue),
      },
      setSearchResult
    );
  };

  return (
    <div className="search-bar">
      <h3>Binary Search</h3>
      <p className="search-note">
        Note: Binary search works on sorted data. The list will be automatically
        sorted before searching.
      </p>

      <div className="search-controls">
        <div className="search-group">
          <label>Search By:</label>
          <select
            value={searchBy}
            onChange={(e) => setSearchBy(e.target.value)}
          >
            <option value="roll_no">Roll Number</option>
            <option value="marks">Marks</option>
          </select>
        </div>

        <div className="search-group">
          <label>Enter Value:</label>
          <input
            type="number"
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            placeholder={`Enter ${
              searchBy === 'roll_no' ? 'roll number' : 'marks'
            }`}
          />
        </div>

        <button onClick={handleSearch} className="btn btn-search">
          Search
        </button>
      </div>

      {searchResult && (
        <div className="search-result">
          {searchResult.found ? (
            <div className="result-found">
              <h4>✓ Student Found!</h4>
              <div className="result-details">
                <p>
                  <strong>Name:</strong> {searchResult.student.name}
                </p>
                <p>
                  <strong>Roll No:</strong> {searchResult.student.roll_no}
                </p>
                <p>
                  <strong>Marks:</strong> {searchResult.student.marks}
                </p>
              </div>
            </div>
          ) : (
            <div className="result-not-found">
              <h4>✗ Student Not Found</h4>
              <p>No student with the given {searchBy} exists.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default SearchBar;