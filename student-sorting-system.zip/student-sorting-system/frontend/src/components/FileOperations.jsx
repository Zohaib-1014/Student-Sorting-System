import React from 'react';
import './FileOperations.css';

function FileOperations({ students, onSave, onLoad }) {
  const handleSave = () => {
    if (students.length === 0) {
      alert('No students to save!');
      return;
    }
    onSave();
  };

  return (
    <div className="file-operations">
      <h3>File Operations</h3>
      <div className="file-buttons">
        <button onClick={handleSave} className="btn btn-save">
          💾 Save to File
        </button>
        <button onClick={onLoad} className="btn btn-load">
          📂 Load from File
        </button>
      </div>
      <p className="file-info">
        Save your student records to a JSON file or load previously saved data.
      </p>
    </div>
  );
}

export default FileOperations;