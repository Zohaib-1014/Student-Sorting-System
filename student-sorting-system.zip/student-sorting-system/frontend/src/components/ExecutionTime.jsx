import React from 'react';
import './ExecutionTime.css';

function ExecutionTime({ executionTime, algorithm }) {
  if (!executionTime) return null;

  return (
    <div className="execution-time">
      <h3>Performance Results</h3>
      <div className="time-card">
        <div className="time-info">
          <span className="label">Algorithm Used:</span>
          <span className="value algorithm-name">
            {algorithm.charAt(0).toUpperCase() + algorithm.slice(1)} Sort
          </span>
        </div>
        <div className="time-info">
          <span className="label">Execution Time:</span>
          <span className="value time-value">{executionTime} ms</span>
        </div>
        <div className="time-bar">
          <div
            className="time-bar-fill"
            style={{
              width: `${Math.min((executionTime / 10) * 100, 100)}%`,
            }}
          ></div>
        </div>
      </div>
    </div>
  );
}

export default ExecutionTime;