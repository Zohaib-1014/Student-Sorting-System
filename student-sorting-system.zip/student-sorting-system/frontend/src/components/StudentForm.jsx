import React, { useState } from 'react';
import './StudentForm.css';

function StudentForm({ onAddStudent }) {
  const [student, setStudent] = useState({
    name: '',
    roll_no: '',
    marks: '',
  });

  const [error, setError] = useState('');

  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setStudent({
      ...student,
      [name]: value,
    });
  };

  // Handle form submit
  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');

    // Validate
    if (!student.name.trim()) {
      setError('Please enter student name');
      return;
    }
    if (!student.roll_no || student.roll_no <= 0) {
      setError('Please enter valid roll number');
      return;
    }
    if (student.marks === '' || student.marks < 0 || student.marks > 100) {
      setError('Marks must be between 0 and 100');
      return;
    }

    // Create student object
    const newStudent = {
      name: student.name.trim(),
      roll_no: parseInt(student.roll_no),
      marks: parseFloat(student.marks),
    };

    // Call parent function
    onAddStudent(newStudent);

    // Reset form
    setStudent({
      name: '',
      roll_no: '',
      marks: '',
    });
  };

  return (
    <div className="student-form">
      <h3>Add Student</h3>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Name:</label>
          <input
            type="text"
            name="name"
            value={student.name}
            onChange={handleChange}
            placeholder="Enter student name"
          />
        </div>

        <div className="form-group">
          <label>Roll Number:</label>
          <input
            type="number"
            name="roll_no"
            value={student.roll_no}
            onChange={handleChange}
            placeholder="Enter roll number"
            min="1"
          />
        </div>

        <div className="form-group">
          <label>Marks:</label>
          <input
            type="number"
            name="marks"
            value={student.marks}
            onChange={handleChange}
            placeholder="Enter marks (0-100)"
            min="0"
            max="100"
            step="0.01"
          />
        </div>

        {error && <div className="error">{error}</div>}

        <button type="submit" className="btn btn-primary">
          Add Student
        </button>
      </form>
    </div>
  );
}

export default StudentForm;