import React from 'react';
import './StudentList.css';

function StudentList({ students, onDeleteStudent, onClearAll }) {
  return (
    <div className="student-list">
      <div className="list-header">
        <h3>Student Records ({students.length})</h3>
        {students.length > 0 && (
          <button onClick={onClearAll} className="btn btn-danger">
            Clear All
          </button>
        )}
      </div>

      {students.length === 0 ? (
        <div className="no-data">
          <p>No students added yet. Please add students using the form above.</p>
        </div>
      ) : (
        <div className="table-container">
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Roll No</th>
                <th>Marks</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {students.map((student) => (
                <tr key={student.id}>
                  <td>{student.id}</td>
                  <td>{student.name}</td>
                  <td>{student.roll_no}</td>
                  <td>
                    <span
                      className="marks-badge"
                      style={{
                        backgroundColor:
                          student.marks >= 90
                            ? '#28a745'
                            : student.marks >= 75
                            ? '#17a2b8'
                            : student.marks >= 60
                            ? '#ffc107'
                            : student.marks >= 40
                            ? '#fd7e14'
                            : '#dc3545',
                      }}
                    >
                      {student.marks}
                    </span>
                  </td>
                  <td>
                    <button
                      onClick={() => onDeleteStudent(student.id)}
                      className="btn btn-delete"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default StudentList;