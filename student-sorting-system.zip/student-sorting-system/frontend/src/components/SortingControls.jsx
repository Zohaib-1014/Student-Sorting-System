import React, { useState } from 'react';
import './SortingControls.css';

function SortingControls({ students, onSort }) {
  const [sortBy, setSortBy] = useState('name');
  const [algorithm, setAlgorithm] = useState('bubble');
  const [order, setOrder] = useState('asc');

  const handleSort = () => {
    if (students.length === 0) {
      alert('Please add students first!');
      return;
    }

    onSort({
      students: students,
      sort_by: sortBy,
      algorithm: algorithm,
      order: order,
    });
  };

  return (
    <div className="sorting-controls">
      <h3>Sorting Options</h3>

      <div className="controls-grid">
        <div className="control-group">
          <label>Sort By:</label>
          <select value={sortBy} onChange={(e) => setSortBy(e.target.value)}>
            <option value="name">Name</option>
            <option value="roll_no">Roll Number</option>
            <option value="marks">Marks</option>
          </select>
        </div>

        <div className="control-group">
          <label>Algorithm:</label>
          <select
            value={algorithm}
            onChange={(e) => setAlgorithm(e.target.value)}
          >
            <option value="bubble">Bubble Sort</option>
            <option value="insertion">Insertion Sort</option>
            <option value="merge">Merge Sort</option>
            <option value="quick">Quick Sort</option>
          </select>
        </div>

        <div className="control-group">
          <label>Order:</label>
          <select value={order} onChange={(e) => setOrder(e.target.value)}>
            <option value="asc">Ascending</option>
            <option value="desc">Descending</option>
          </select>
        </div>

        <div className="control-group">
          <button onClick={handleSort} className="btn btn-sort">
            Sort Students
          </button>
        </div>
      </div>

      <div className="algorithm-info">
        <h4>Algorithm Information:</h4>
        {algorithm === 'bubble' && (
          <p>
            <strong>Bubble Sort:</strong> Simple sorting algorithm. Good for
            small datasets. Time Complexity: O(n²)
          </p>
        )}
        {algorithm === 'insertion' && (
          <p>
            <strong>Insertion Sort:</strong> Efficient for small and partially
            sorted data. Time Complexity: O(n²)
          </p>
        )}
        {algorithm === 'merge' && (
          <p>
            <strong>Merge Sort:</strong> Divide and conquer algorithm. Stable
            and efficient. Time Complexity: O(n log n)
          </p>
        )}
        {algorithm === 'quick' && (
          <p>
            <strong>Quick Sort:</strong> Fast sorting algorithm. Good average
            performance. Time Complexity: O(n log n)
          </p>
        )}
      </div>
    </div>
  );
}

export default SortingControls;